import React, { useContext, useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { BarangaysContext } from "../store/barangays.context";

const Chart = () => {
  const { data } = useContext(BarangaysContext);
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    console.log(data.selected, "charts");
    setChartData(data.selected.water_usage);
  }, [data]);

  console.log(chartData);
  return (
    <div className="mt-10 mx-16 w-[500px] h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        {chartData && (
          <LineChart
            width={500}
            height={300}
            data={chartData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="barangay" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="cubic_meters"
              stroke="#8884d8"
              activeDot={{ r: 8 }}
            />
            <Line type="monotone" dataKey="cubic_meters" stroke="#82ca9d" />
          </LineChart>
        )}
      </ResponsiveContainer>
    </div>
  );
};

export default Chart;
