import React, { useContext, useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { BarangaysContext } from "../store/barangays.context";

const Chart = () => {
  const { data } = useContext(BarangaysContext);
  const [chartData, setChartData] = useState([]);
  const [predData, setPredData] = useState([]);

  useEffect(() => {
    console.log(data.selected, "charts");
    setChartData(data.selected.water_usage);
    setPredData(data.selected.pred);
  }, [data]);

  console.log(chartData);
  console.log(predData);
  return (
    <div className="mt-10 w-[600px] h-[250px]">
      <h2 className="pb-5 text-md text-white">Water Consumption per Month</h2>
      <ResponsiveContainer width="100%" height="100%">
        {chartData && (
          <LineChart
            width={500}
            height={300}
            data={chartData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="5 5" />
            <XAxis dataKey="Date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="water_usage"
              stroke="#8884d8"
              activeDot={{ r: 8 }}
            />
          </LineChart>
        )}
      </ResponsiveContainer>
      <h2 className="pt-5 text-md  text-white">
        Water Consumption Prediction for the next 12 months
      </h2>
      <ResponsiveContainer width="100%" height="100%" className="mt-5">
        {chartData && (
          <LineChart
            width={500}
            height={300}
            data={predData}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="5 5" />
            <XAxis dataKey="Date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="Prediction"
              stroke="#8884d8"
              activeDot={{ r: 8 }}
            />
          </LineChart>
        )}
      </ResponsiveContainer>
    </div>
  );
};

export default Chart;
