import React from "react";

const BrgyBtn = ({ Icon, name, data }) => {
  return (
    <div className="py-3 px-10 flex hover:bg-zinc-500  hover:text-white ease-in-out duration-300 rounded-md cursor-pointer">
      <Icon className="text-white" />
      <button className="pl-1 text-white">{name}</button>
    </div>
  );
};

export default BrgyBtn;
