import React from "react";

const Navbar = () => {
  return (
    <div className="w-[100%] relative h-[10vh] bg-zinc-300 shadow-lg z-30">
      <div className="">
        <h2 className="text-center py-6 font-bold text-3xl">
          Water Conservation for Municipality of Santa Rosa
        </h2>
      </div>
    </div>
  );
};

export default Navbar;
