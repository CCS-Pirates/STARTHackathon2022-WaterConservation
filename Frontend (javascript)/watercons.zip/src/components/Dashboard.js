import React, { useContext, useEffect, useState } from "react";
import MapTwoToneIcon from "@mui/icons-material/MapTwoTone";
import BrgyBtn from "./component/BrgyBtn";
import Map from "./Map";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import Chart from "./Chart";
import { BarangaysContext } from "../store/barangays.context";

const Dashboard = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { data, setSelectedData } = useContext(BarangaysContext);

  return (
    <div className="w-[100%] h-[100%]  bg-[#002B5B]">
      <div className="flex justify-around ">
        <div className="flex-[0.6] relative">
          <div className="flex items-center mt-5 ml-10 py-1 px-7 text-[#8FE3CF] hover:bg-zinc-500 hover:text-white ease-in-out duration-300 rounded-2xl cursor-pointer w-[20%]">
            <button onClick={() => setIsOpen(!isOpen)} className="py-1 px-5">
              Select Barangay
            </button>
            <KeyboardArrowDownIcon />
          </div>
          <div>
            <select
              name=""
              id=""
              onChange={(e) => {
                setSelectedData(e.target.value);
              }}
            >
              {data &&
                data?.barangays.map((i) => (
                  <option key={i.barangay} value={i.barangay}>
                    {i.barangay}
                  </option>
                ))}
            </select>
          </div>
          {isOpen && (
            <div className="origin-top-left absolute left-0 ml-16 w-[350px] rounded-md shadow-lg bg-blue-300/[0.15] )] backdrop-blur-[10px] ring-1 ring-black ring-opacity-5 divide-y focus:outline-none ">
              <div className="flex">
                {/* <div>
                  {data &&
                    data.map((i) => (
                      <BrgyBtn
                        name={i.barangay}
                        Icon={MapTwoToneIcon}
                        data=""
                      />
                    ))}
                </div> */}
                {/* <div>
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                  <BrgyBtn name="Aplaya" Icon={MapTwoToneIcon} />
                </div> */}
              </div>
            </div>
          )}
          <Map />
        </div>
        <div className="flex-[0.4]">
          <div className="py-5">
            <Chart />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
