import React, { useContext, useState } from "react";
import Map from "./Map";
import Chart from "./Chart";
import { BarangaysContext } from "../store/barangays.context";

const Dashboard = () => {
  const { data, setSelectedData } = useContext(BarangaysContext);

  return (
    <div className="w-[100%] h-[100%]  bg-[#002B5B]">
      <div className="flex justify-around ">
        <div className="flex-[0.4] relative">
          <div>
            <select
              className="flex items-center mt-5 ml-16 py-1 px-7 text-[#8FE3CF] color-zinc- hover:bg-zinc-500 hover:text-white ease-in-out duration-300 rounded-2xl cursor-pointer w-[20%]"
              name=""
              id=""
              onChange={(e) => {
                setSelectedData(e.target.value);
              }}
            >
              {data &&
                data?.barangays.map((i) => (
                  <option key={i.barangay} value={i.barangay}>
                    {i.barangay}
                  </option>
                ))}
            </select>
          </div>
          <Map mapselect={data} />
        </div>
        <div className="flex-[0.6] ">
          <div className="py-5 z-20">
            <Chart />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
