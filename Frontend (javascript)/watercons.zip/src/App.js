import React from "react";
import Dashboard from "./components/Dashboard";
import Navbar from "./components/Navbar";
import { Counter } from "./features/counter/Counter";

function App() {
  return (
    <>
      <div className="w-[100vw] h-[100vh] overflow-x-hidden">
        <Navbar />
        <Dashboard />
      </div>
    </>
  );
}

export default App;
