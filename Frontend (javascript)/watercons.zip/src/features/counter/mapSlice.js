import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  map: null,
};

const mapSlice = createSlice({
  name: "map",
  initialState,
  reducers: {},
});

export const {} = mapSlice.actions;

export default mapSlice.reducer;
