import { createContext, useState } from "react";

import { BARANGAYS_MOCK_DATA } from "../mocks/barangays.mocks";

export const BarangaysContext = createContext({
  data: null,
  seData: () => {},
  setSelectedData: () => {},
});

export const BarangaysContextProvider = ({ children }) => {
  const [state, setState] = useState({
    barangays: BARANGAYS_MOCK_DATA,
    selected: BARANGAYS_MOCK_DATA[0],
  });

  const setData = (data) => {
    setState((prev) => {
      return {
        ...state,
        data,
      };
    });
  };

  const setSelectedData = (identifier) => {
    const selected = state.barangays.find((i) => i.barangay === identifier);

    setState((prev) => {
      return {
        ...state,
        selected: selected,
        // selected: state.data.find((i) => i.barangay === identifier),
      };
    });
  };

  const value = {
    data: state,
    setData,
    setSelectedData,
  };

  return (
    <BarangaysContext.Provider value={value}>
      {children}
    </BarangaysContext.Provider>
  );
};
