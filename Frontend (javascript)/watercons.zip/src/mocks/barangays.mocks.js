export const BARANGAYS_MOCK_DATA = [
  {
    barangay: "barangay1",
    water_usage: [
      {
        label: "January",
        cubic_meters: "3861478.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
      {
        label: "February",
        cubic_meters: "123232.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
      {
        label: "March",
        cubic_meters: "432342.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
    ],
  },
  {
    barangay: "barangay2",
    water_usage: [
      {
        label: "January",
        cubic_meters: "3861478.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
      {
        label: "February",
        cubic_meters: "722222.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
      {
        label: "March",
        cubic_meters: "432222.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
    ],
  },
  {
    barangay: "barangay3",
    water_usage: [
      {
        label: "January",
        cubic_meters: "1111111.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
      {
        label: "February",
        cubic_meters: "444444.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
      {
        label: "March",
        cubic_meters: "100000.53",
        status: "normal", // enum(normal, warning, critical base on cubic_meters)
      },
    ],
  },
];
