// export const BARANGAYS_MOCK_DATA = [
//   {
//     schema: {
//       fields: [
//         {
//           name: index,
//           type: "integer",
//         },
//         {
//           name: Date,
//           type: "datetime",
//         },
//         {
//           name: ""water_usage"",
//           type: "number",
//         },
//         {
//           name: "Barangay",
//           type: "string",
//         },
//       ],
//       primaryKey: [index],
//       pandas_version: "0.20.0",
//     },
//     data:
//   },
// ];

export const BARANGAYS_MOCK_DATA = [
  {
    barangay: "Sta Rosa",
    water_usage: [
      {
        index: 0,
        Date: "2016-01-31T00:00:00.000Z",
        water_usage: 159712800.0,
      },
      {
        index: 1,
        Date: "2016-02-29T00:00:00.000Z",
        water_usage: 119784600.0,
      },
      {
        index: 2,
        Date: "2016-03-31T00:00:00.000Z",
        water_usage: 179676900.0,
      },
      {
        index: 3,
        Date: "2016-04-30T00:00:00.000Z",
        water_usage: 139748700.0,
      },
      {
        index: 4,
        Date: "2016-05-31T00:00:00.000Z",
        water_usage: 159712800.0,
      },
      {
        index: 5,
        Date: "2016-06-30T00:00:00.000Z",
        water_usage: 159712800.0,
      },
      {
        index: 6,
        Date: "2016-07-31T00:00:00.000Z",
        water_usage: 159712800.0,
      },
      {
        index: 7,
        Date: "2016-08-31T00:00:00.000Z",
        water_usage: 79856400.0,
      },
      {
        index: 8,
        Date: "2016-09-30T00:00:00.000Z",
        water_usage: 359353799.999999,
      },
      {
        index: 9,
        Date: "2016-10-31T00:00:00.000Z",
        water_usage: 99820500.0,
      },
      {
        index: 10,
        Date: "2016-11-30T00:00:00.000Z",
        water_usage: 79856400.0,
      },
      {
        index: 11,
        Date: "2016-12-31T00:00:00.000Z",
        water_usage: 299461500.0,
      },
      {
        index: 12,
        Date: "2017-01-31T00:00:00.000Z",
        water_usage: 165926400.0,
      },
      {
        index: 13,
        Date: "2017-02-28T00:00:00.000Z",
        water_usage: 124444800.0,
      },
      {
        index: 14,
        Date: "2017-03-31T00:00:00.000Z",
        water_usage: 186667200.0,
      },
      {
        index: 15,
        Date: "2017-04-30T00:00:00.000Z",
        water_usage: 145185600.0,
      },
      {
        index: 16,
        Date: "2017-05-31T00:00:00.000Z",
        water_usage: 165926400.0,
      },
      {
        index: 17,
        Date: "2017-06-30T00:00:00.000Z",
        water_usage: 165926400.0,
      },
      {
        index: 18,
        Date: "2017-07-31T00:00:00.000Z",
        water_usage: 165926400.0,
      },
      {
        index: 19,
        Date: "2017-08-31T00:00:00.000Z",
        water_usage: 165926400.0,
      },
      {
        index: 20,
        Date: "2017-09-30T00:00:00.000Z",
        water_usage: 290371199.999999,
      },
      {
        index: 21,
        Date: "2017-10-31T00:00:00.000Z",
        water_usage: 103704000.0,
      },
      {
        index: 22,
        Date: "2017-11-30T00:00:00.000Z",
        water_usage: 82963200.0,
      },
      {
        index: 23,
        Date: "2017-12-31T00:00:00.000Z",
        water_usage: 311112000.0,
      },
      {
        index: 24,
        Date: "2018-01-31T00:00:00.000Z",
        water_usage: 177376000.0,
      },
      {
        index: 25,
        Date: "2018-02-28T00:00:00.000Z",
        water_usage: 133032000.0,
      },
      {
        index: 26,
        Date: "2018-03-31T00:00:00.000Z",
        water_usage: 199548000.0,
      },
      {
        index: 27,
        Date: "2018-04-30T00:00:00.000Z",
        water_usage: 155204000.0,
      },
      {
        index: 28,
        Date: "2018-05-31T00:00:00.000Z",
        water_usage: 177376000.0,
      },
      {
        index: 29,
        Date: "2018-06-30T00:00:00.000Z",
        water_usage: 177376000.0,
      },
      {
        index: 30,
        Date: "2018-07-31T00:00:00.000Z",
        water_usage: 177376000.0,
      },
      {
        index: 31,
        Date: "2018-08-31T00:00:00.000Z",
        water_usage: 155204000.0,
      },
      {
        index: 32,
        Date: "2018-09-30T00:00:00.000Z",
        water_usage: 354751999.999999,
      },
      {
        index: 33,
        Date: "2018-10-31T00:00:00.000Z",
        water_usage: 88688000.0,
      },
      {
        index: 34,
        Date: "2018-11-30T00:00:00.000Z",
        water_usage: 88688000.0,
      },
      {
        index: 35,
        Date: "2018-12-31T00:00:00.000Z",
        water_usage: 332580000.0,
      },
      {
        index: 36,
        Date: "2019-01-31T00:00:00.000Z",
        water_usage: 117566500.0,
      },
      {
        index: 37,
        Date: "2019-02-28T00:00:00.000Z",
        water_usage: 141079800.0,
      },
      {
        index: 38,
        Date: "2019-03-31T00:00:00.000Z",
        water_usage: 211619700.0,
      },
      {
        index: 39,
        Date: "2019-04-30T00:00:00.000Z",
        water_usage: 164593100.0,
      },
      {
        index: 40,
        Date: "2019-05-31T00:00:00.000Z",
        water_usage: 188106400.0,
      },
      {
        index: 41,
        Date: "2019-06-30T00:00:00.000Z",
        water_usage: 117566500.0,
      },
      {
        index: 42,
        Date: "2019-07-31T00:00:00.000Z",
        water_usage: 117566500.0,
      },
      {
        index: 43,
        Date: "2019-08-31T00:00:00.000Z",
        water_usage: 164593100.0,
      },
      {
        index: 44,
        Date: "2019-09-30T00:00:00.000Z",
        water_usage: 587832499.999999,
      },
      {
        index: 45,
        Date: "2019-10-31T00:00:00.000Z",
        water_usage: 94053200.0,
      },
      {
        index: 46,
        Date: "2019-11-30T00:00:00.000Z",
        water_usage: 94053200.0,
      },
      {
        index: 47,
        Date: "2019-12-31T00:00:00.000Z",
        water_usage: 352699500.0,
      },
      {
        index: 48,
        Date: "2020-01-31T00:00:00.000Z",
        water_usage: 146673000.0,
      },
      {
        index: 49,
        Date: "2020-02-29T00:00:00.000Z",
        water_usage: 146673000.0,
      },
      {
        index: 50,
        Date: "2020-03-31T00:00:00.000Z",
        water_usage: 220009500.0,
      },
      {
        index: 51,
        Date: "2020-04-30T00:00:00.000Z",
        water_usage: 171118500.0,
      },
      {
        index: 52,
        Date: "2020-05-31T00:00:00.000Z",
        water_usage: 195564000.0,
      },
      {
        index: 53,
        Date: "2020-06-30T00:00:00.000Z",
        water_usage: 146673000.0,
      },
      {
        index: 54,
        Date: "2020-07-31T00:00:00.000Z",
        water_usage: 146673000.0,
      },
      {
        index: 55,
        Date: "2020-08-31T00:00:00.000Z",
        water_usage: 146673000.0,
      },
      {
        index: 56,
        Date: "2020-09-30T00:00:00.000Z",
        water_usage: 537800999.999999,
      },
      {
        index: 57,
        Date: "2020-10-31T00:00:00.000Z",
        water_usage: 122227500.0,
      },
      {
        index: 58,
        Date: "2020-11-30T00:00:00.000Z",
        water_usage: 97782000.0,
      },
      {
        index: 59,
        Date: "2020-12-31T00:00:00.000Z",
        water_usage: 366682500.0,
      },
    ],
    pred: [
      {
        Date: "2021-01-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2021-02-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2021-03-01T00:00:00.000Z",
        Prediction: 220009500.0,
      },
      {
        Date: "2021-04-01T00:00:00.000Z",
        Prediction: 171118500.0,
      },
      {
        Date: "2021-05-01T00:00:00.000Z",
        Prediction: 195564000.0,
      },
      {
        Date: "2021-06-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2021-07-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2021-08-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2021-09-01T00:00:00.000Z",
        Prediction: 537801000.0,
      },
      {
        Date: "2021-10-01T00:00:00.000Z",
        Prediction: 122227500.0,
      },
      {
        Date: "2021-11-01T00:00:00.000Z",
        Prediction: 97782000.0,
      },
      {
        Date: "2021-12-01T00:00:00.000Z",
        Prediction: 366682500.0,
      },
      {
        Date: "2022-01-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2022-02-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2022-03-01T00:00:00.000Z",
        Prediction: 220009500.0,
      },
      {
        Date: "2022-04-01T00:00:00.000Z",
        Prediction: 171118500.0,
      },
      {
        Date: "2022-05-01T00:00:00.000Z",
        Prediction: 195564000.0,
      },
      {
        Date: "2022-06-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2022-07-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2022-08-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2022-09-01T00:00:00.000Z",
        Prediction: 537801000.0,
      },
      {
        Date: "2022-10-01T00:00:00.000Z",
        Prediction: 122227500.0,
      },
      {
        Date: "2022-11-01T00:00:00.000Z",
        Prediction: 97782000.0,
      },
      {
        Date: "2022-12-01T00:00:00.000Z",
        Prediction: 366682500.0,
      },
      {
        Date: "2023-01-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2023-02-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2023-03-01T00:00:00.000Z",
        Prediction: 220009500.0,
      },
      {
        Date: "2023-04-01T00:00:00.000Z",
        Prediction: 171118500.0,
      },
      {
        Date: "2023-05-01T00:00:00.000Z",
        Prediction: 195564000.0,
      },
      {
        Date: "2023-06-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2023-07-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2023-08-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2023-09-01T00:00:00.000Z",
        Prediction: 537801000.0,
      },
      {
        Date: "2023-10-01T00:00:00.000Z",
        Prediction: 122227500.0,
      },
      {
        Date: "2023-11-01T00:00:00.000Z",
        Prediction: 97782000.0,
      },
      {
        Date: "2023-12-01T00:00:00.000Z",
        Prediction: 366682500.0,
      },
      {
        Date: "2024-01-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2024-02-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2024-03-01T00:00:00.000Z",
        Prediction: 220009500.0,
      },
      {
        Date: "2024-04-01T00:00:00.000Z",
        Prediction: 171118500.0,
      },
      {
        Date: "2024-05-01T00:00:00.000Z",
        Prediction: 195564000.0,
      },
      {
        Date: "2024-06-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2024-07-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2024-08-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2024-09-01T00:00:00.000Z",
        Prediction: 537801000.0,
      },
      {
        Date: "2024-10-01T00:00:00.000Z",
        Prediction: 122227500.0,
      },
      {
        Date: "2024-11-01T00:00:00.000Z",
        Prediction: 97782000.0,
      },
      {
        Date: "2024-12-01T00:00:00.000Z",
        Prediction: 366682500.0,
      },
      {
        Date: "2025-01-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2025-02-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2025-03-01T00:00:00.000Z",
        Prediction: 220009500.0,
      },
      {
        Date: "2025-04-01T00:00:00.000Z",
        Prediction: 171118500.0,
      },
      {
        Date: "2025-05-01T00:00:00.000Z",
        Prediction: 195564000.0,
      },
      {
        Date: "2025-06-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2025-07-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2025-08-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2025-09-01T00:00:00.000Z",
        Prediction: 537801000.0,
      },
      {
        Date: "2025-10-01T00:00:00.000Z",
        Prediction: 122227500.0,
      },
      {
        Date: "2025-11-01T00:00:00.000Z",
        Prediction: 97782000.0,
      },
      {
        Date: "2025-12-01T00:00:00.000Z",
        Prediction: 366682500.0,
      },
      {
        Date: "2026-01-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2026-02-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2026-03-01T00:00:00.000Z",
        Prediction: 220009500.0,
      },
      {
        Date: "2026-04-01T00:00:00.000Z",
        Prediction: 171118500.0,
      },
      {
        Date: "2026-05-01T00:00:00.000Z",
        Prediction: 195564000.0,
      },
      {
        Date: "2026-06-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2026-07-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2026-08-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2026-09-01T00:00:00.000Z",
        Prediction: 537801000.0,
      },
      {
        Date: "2026-10-01T00:00:00.000Z",
        Prediction: 122227500.0,
      },
      {
        Date: "2026-11-01T00:00:00.000Z",
        Prediction: 97782000.0,
      },
      {
        Date: "2026-12-01T00:00:00.000Z",
        Prediction: 366682500.0,
      },
      {
        Date: "2027-01-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2027-02-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2027-03-01T00:00:00.000Z",
        Prediction: 220009500.0,
      },
      {
        Date: "2027-04-01T00:00:00.000Z",
        Prediction: 171118500.0,
      },
      {
        Date: "2027-05-01T00:00:00.000Z",
        Prediction: 195564000.0,
      },
      {
        Date: "2027-06-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2027-07-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2027-08-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2027-09-01T00:00:00.000Z",
        Prediction: 537801000.0,
      },
      {
        Date: "2027-10-01T00:00:00.000Z",
        Prediction: 122227500.0,
      },
      {
        Date: "2027-11-01T00:00:00.000Z",
        Prediction: 97782000.0,
      },
      {
        Date: "2027-12-01T00:00:00.000Z",
        Prediction: 366682500.0,
      },
      {
        Date: "2028-01-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2028-02-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
      {
        Date: "2028-03-01T00:00:00.000Z",
        Prediction: 220009500.0,
      },
      {
        Date: "2028-04-01T00:00:00.000Z",
        Prediction: 171118500.0,
      },
      {
        Date: "2028-05-01T00:00:00.000Z",
        Prediction: 195564000.0,
      },
      {
        Date: "2028-06-01T00:00:00.000Z",
        Prediction: 146673000.0,
      },
    ],
  },
  {
    barangay: "Aplaya",
    water_usage: [
      {
        index: 0,
        Date: "2016-01-31T00:00:00.000Z",
        water_usage: 3861478.53,
      },
      {
        index: 1,
        Date: "2016-02-29T00:00:00.000Z",
        water_usage: 4633774.23,
      },
      {
        index: 2,
        Date: "2016-03-31T00:00:00.000Z",
        water_usage: 6950661.35,
      },
      {
        index: 3,
        Date: "2016-04-30T00:00:00.000Z",
        water_usage: 5406069.94,
      },
      {
        index: 4,
        Date: "2016-05-31T00:00:00.000Z",
        water_usage: 6178365.65,
      },
      {
        index: 5,
        Date: "2016-06-30T00:00:00.000Z",
        water_usage: 3861478.53,
      },
      {
        index: 6,
        Date: "2016-07-31T00:00:00.000Z",
        water_usage: 3861478.53,
      },
      {
        index: 7,
        Date: "2016-08-31T00:00:00.000Z",
        water_usage: 4633774.23,
      },
      {
        index: 8,
        Date: "2016-09-30T00:00:00.000Z",
        water_usage: 17762801.24,
      },
      {
        index: 9,
        Date: "2016-10-31T00:00:00.000Z",
        water_usage: 5406069.94,
      },
      {
        index: 10,
        Date: "2016-11-30T00:00:00.000Z",
        water_usage: 3089182.82,
      },
      {
        index: 11,
        Date: "2016-12-31T00:00:00.000Z",
        water_usage: 11584435.59,
      },
      {
        index: 12,
        Date: "2017-01-31T00:00:00.000Z",
        water_usage: 3209366.97,
      },
      {
        index: 13,
        Date: "2017-02-28T00:00:00.000Z",
        water_usage: 4814050.45,
      },
      {
        index: 14,
        Date: "2017-03-31T00:00:00.000Z",
        water_usage: 7221075.68,
      },
      {
        index: 15,
        Date: "2017-04-30T00:00:00.000Z",
        water_usage: 5616392.2,
      },
      {
        index: 16,
        Date: "2017-05-31T00:00:00.000Z",
        water_usage: 6418733.94,
      },
      {
        index: 17,
        Date: "2017-06-30T00:00:00.000Z",
        water_usage: 3209366.97,
      },
      {
        index: 18,
        Date: "2017-07-31T00:00:00.000Z",
        water_usage: 3209366.97,
      },
      {
        index: 19,
        Date: "2017-08-31T00:00:00.000Z",
        water_usage: 6418733.94,
      },
      {
        index: 20,
        Date: "2017-09-30T00:00:00.000Z",
        water_usage: 19256201.82,
      },
      {
        index: 21,
        Date: "2017-10-31T00:00:00.000Z",
        water_usage: 5616392.2,
      },
      {
        index: 22,
        Date: "2017-11-30T00:00:00.000Z",
        water_usage: 3209366.97,
      },
      {
        index: 23,
        Date: "2017-12-31T00:00:00.000Z",
        water_usage: 12035126.14,
      },
      {
        index: 24,
        Date: "2018-01-31T00:00:00.000Z",
        water_usage: 6861652.82,
      },
      {
        index: 25,
        Date: "2018-02-28T00:00:00.000Z",
        water_usage: 5146239.62,
      },
      {
        index: 26,
        Date: "2018-03-31T00:00:00.000Z",
        water_usage: 7719359.43,
      },
      {
        index: 27,
        Date: "2018-04-30T00:00:00.000Z",
        water_usage: 6003946.22,
      },
      {
        index: 28,
        Date: "2018-05-31T00:00:00.000Z",
        water_usage: 6861652.82,
      },
      {
        index: 29,
        Date: "2018-06-30T00:00:00.000Z",
        water_usage: 6861652.82,
      },
      {
        index: 30,
        Date: "2018-07-31T00:00:00.000Z",
        water_usage: 6861652.82,
      },
      {
        index: 31,
        Date: "2018-08-31T00:00:00.000Z",
        water_usage: 6003946.22,
      },
      {
        index: 32,
        Date: "2018-09-30T00:00:00.000Z",
        water_usage: 11150185.84,
      },
      {
        index: 33,
        Date: "2018-10-31T00:00:00.000Z",
        water_usage: 6003946.22,
      },
      {
        index: 34,
        Date: "2018-11-30T00:00:00.000Z",
        water_usage: 3430826.41,
      },
      {
        index: 35,
        Date: "2018-12-31T00:00:00.000Z",
        water_usage: 12865599.05,
      },
      {
        index: 36,
        Date: "2019-01-31T00:00:00.000Z",
        water_usage: 5457562.51,
      },
      {
        index: 37,
        Date: "2019-02-28T00:00:00.000Z",
        water_usage: 5457562.51,
      },
      {
        index: 38,
        Date: "2019-03-31T00:00:00.000Z",
        water_usage: 8186343.77,
      },
      {
        index: 39,
        Date: "2019-04-30T00:00:00.000Z",
        water_usage: 6367156.26,
      },
      {
        index: 40,
        Date: "2019-05-31T00:00:00.000Z",
        water_usage: 7276750.02,
      },
      {
        index: 41,
        Date: "2019-06-30T00:00:00.000Z",
        water_usage: 5457562.51,
      },
      {
        index: 42,
        Date: "2019-07-31T00:00:00.000Z",
        water_usage: 5457562.51,
      },
      {
        index: 43,
        Date: "2019-08-31T00:00:00.000Z",
        water_usage: 5457562.51,
      },
      {
        index: 44,
        Date: "2019-09-30T00:00:00.000Z",
        water_usage: 19101468.8,
      },
      {
        index: 45,
        Date: "2019-10-31T00:00:00.000Z",
        water_usage: 5457562.51,
      },
      {
        index: 46,
        Date: "2019-11-30T00:00:00.000Z",
        water_usage: 3638375.01,
      },
      {
        index: 47,
        Date: "2019-12-31T00:00:00.000Z",
        water_usage: 13643906.28,
      },
      {
        index: 48,
        Date: "2020-01-31T00:00:00.000Z",
        water_usage: 6367156.26,
      },
      {
        index: 49,
        Date: "2020-02-29T00:00:00.000Z",
        water_usage: 5457562.51,
      },
      {
        index: 50,
        Date: "2020-03-31T00:00:00.000Z",
        water_usage: 8186343.77,
      },
      {
        index: 51,
        Date: "2020-04-30T00:00:00.000Z",
        water_usage: 6367156.26,
      },
      {
        index: 52,
        Date: "2020-05-31T00:00:00.000Z",
        water_usage: 7276750.02,
      },
      {
        index: 53,
        Date: "2020-06-30T00:00:00.000Z",
        water_usage: 6367156.26,
      },
      {
        index: 54,
        Date: "2020-07-31T00:00:00.000Z",
        water_usage: 6367156.26,
      },
      {
        index: 55,
        Date: "2020-08-31T00:00:00.000Z",
        water_usage: 6367156.26,
      },
      {
        index: 56,
        Date: "2020-09-30T00:00:00.000Z",
        water_usage: 16372687.54,
      },
      {
        index: 57,
        Date: "2020-10-31T00:00:00.000Z",
        water_usage: 4547968.76,
      },
      {
        index: 58,
        Date: "2020-11-30T00:00:00.000Z",
        water_usage: 3638375.01,
      },
      {
        index: 59,
        Date: "2020-12-31T00:00:00.000Z",
        water_usage: 13643906.28,
      },
    ],
    pred: [
      {
        Date: "2021-01-01T00:00:00.000Z",
        Prediction: 5751185.9902,
      },
      {
        Date: "2021-02-01T00:00:00.000Z",
        Prediction: 5559614.2401,
      },
      {
        Date: "2021-03-01T00:00:00.000Z",
        Prediction: 8327128.733,
      },
      {
        Date: "2021-04-01T00:00:00.000Z",
        Prediction: 6506248.1864,
      },
      {
        Date: "2021-05-01T00:00:00.000Z",
        Prediction: 7453782.7054,
      },
      {
        Date: "2021-06-01T00:00:00.000Z",
        Prediction: 5813804.5696,
      },
      {
        Date: "2021-07-01T00:00:00.000Z",
        Prediction: 5336544.5314,
      },
      {
        Date: "2021-08-01T00:00:00.000Z",
        Prediction: 6222515.0035,
      },
      {
        Date: "2021-09-01T00:00:00.000Z",
        Prediction: 18625103.6107,
      },
      {
        Date: "2021-10-01T00:00:00.000Z",
        Prediction: 6219941.8268,
      },
      {
        Date: "2021-11-01T00:00:00.000Z",
        Prediction: 3683039.806,
      },
      {
        Date: "2021-12-01T00:00:00.000Z",
        Prediction: 13775648.7068,
      },
    ],
  },
  {
    barangay: "Balibago",
    water_usage: [
      {
        index: 0,
        Date: "2016-01-31T00:00:00.000Z",
        water_usage: 10770788.0,
      },
      {
        index: 1,
        Date: "2016-02-29T00:00:00.000Z",
        water_usage: 9232104.0,
      },
      {
        index: 2,
        Date: "2016-03-31T00:00:00.000Z",
        water_usage: 13848156.0,
      },
      {
        index: 3,
        Date: "2016-04-30T00:00:00.000Z",
        water_usage: 10770788.0,
      },
      {
        index: 4,
        Date: "2016-05-31T00:00:00.000Z",
        water_usage: 12309472.0,
      },
      {
        index: 5,
        Date: "2016-06-30T00:00:00.000Z",
        water_usage: 10770788.0,
      },
      {
        index: 6,
        Date: "2016-07-31T00:00:00.000Z",
        water_usage: 10770788.0,
      },
      {
        index: 7,
        Date: "2016-08-31T00:00:00.000Z",
        water_usage: 7693420.0,
      },
      {
        index: 8,
        Date: "2016-09-30T00:00:00.000Z",
        water_usage: 29234996.01,
      },
      {
        index: 9,
        Date: "2016-10-31T00:00:00.000Z",
        water_usage: 9232104.0,
      },
      {
        index: 10,
        Date: "2016-11-30T00:00:00.000Z",
        water_usage: 6154736.0,
      },
      {
        index: 11,
        Date: "2016-12-31T00:00:00.000Z",
        water_usage: 23080260.01,
      },
      {
        index: 12,
        Date: "2017-01-31T00:00:00.000Z",
        water_usage: 7992731.23,
      },
      {
        index: 13,
        Date: "2017-02-28T00:00:00.000Z",
        water_usage: 9591277.47,
      },
      {
        index: 14,
        Date: "2017-03-31T00:00:00.000Z",
        water_usage: 14386916.21,
      },
      {
        index: 15,
        Date: "2017-04-30T00:00:00.000Z",
        water_usage: 11189823.72,
      },
      {
        index: 16,
        Date: "2017-05-31T00:00:00.000Z",
        water_usage: 12788369.96,
      },
      {
        index: 17,
        Date: "2017-06-30T00:00:00.000Z",
        water_usage: 7992731.23,
      },
      {
        index: 18,
        Date: "2017-07-31T00:00:00.000Z",
        water_usage: 7992731.23,
      },
      {
        index: 19,
        Date: "2017-08-31T00:00:00.000Z",
        water_usage: 6394184.98,
      },
      {
        index: 20,
        Date: "2017-09-30T00:00:00.000Z",
        water_usage: 44759294.88,
      },
      {
        index: 21,
        Date: "2017-10-31T00:00:00.000Z",
        water_usage: 6394184.98,
      },
      {
        index: 22,
        Date: "2017-11-30T00:00:00.000Z",
        water_usage: 6394184.98,
      },
      {
        index: 23,
        Date: "2017-12-31T00:00:00.000Z",
        water_usage: 23978193.68,
      },
      {
        index: 24,
        Date: "2018-01-31T00:00:00.000Z",
        water_usage: 8544262.36,
      },
      {
        index: 25,
        Date: "2018-02-28T00:00:00.000Z",
        water_usage: 10253114.83,
      },
      {
        index: 26,
        Date: "2018-03-31T00:00:00.000Z",
        water_usage: 15379672.25,
      },
      {
        index: 27,
        Date: "2018-04-30T00:00:00.000Z",
        water_usage: 11961967.31,
      },
      {
        index: 28,
        Date: "2018-05-31T00:00:00.000Z",
        water_usage: 13670819.78,
      },
      {
        index: 29,
        Date: "2018-06-30T00:00:00.000Z",
        water_usage: 8544262.36,
      },
      {
        index: 30,
        Date: "2018-07-31T00:00:00.000Z",
        water_usage: 8544262.36,
      },
      {
        index: 31,
        Date: "2018-08-31T00:00:00.000Z",
        water_usage: 8544262.36,
      },
      {
        index: 32,
        Date: "2018-09-30T00:00:00.000Z",
        water_usage: 39303606.87,
      },
      {
        index: 33,
        Date: "2018-10-31T00:00:00.000Z",
        water_usage: 13670819.78,
      },
      {
        index: 34,
        Date: "2018-11-30T00:00:00.000Z",
        water_usage: 6835409.89,
      },
      {
        index: 35,
        Date: "2018-12-31T00:00:00.000Z",
        water_usage: 25632787.09,
      },
      {
        index: 36,
        Date: "2019-01-31T00:00:00.000Z",
        water_usage: 14497839.02,
      },
      {
        index: 37,
        Date: "2019-02-28T00:00:00.000Z",
        water_usage: 10873379.26,
      },
      {
        index: 38,
        Date: "2019-03-31T00:00:00.000Z",
        water_usage: 16310068.9,
      },
      {
        index: 39,
        Date: "2019-04-30T00:00:00.000Z",
        water_usage: 12685609.14,
      },
      {
        index: 40,
        Date: "2019-05-31T00:00:00.000Z",
        water_usage: 14497839.02,
      },
      {
        index: 41,
        Date: "2019-06-30T00:00:00.000Z",
        water_usage: 14497839.02,
      },
      {
        index: 42,
        Date: "2019-07-31T00:00:00.000Z",
        water_usage: 14497839.02,
      },
      {
        index: 43,
        Date: "2019-08-31T00:00:00.000Z",
        water_usage: 12685609.14,
      },
      {
        index: 44,
        Date: "2019-09-30T00:00:00.000Z",
        water_usage: 23558988.41,
      },
      {
        index: 45,
        Date: "2019-10-31T00:00:00.000Z",
        water_usage: 12685609.14,
      },
      {
        index: 46,
        Date: "2019-11-30T00:00:00.000Z",
        water_usage: 7248919.51,
      },
      {
        index: 47,
        Date: "2019-12-31T00:00:00.000Z",
        water_usage: 27183448.17,
      },
      {
        index: 48,
        Date: "2020-01-31T00:00:00.000Z",
        water_usage: 9420384.52,
      },
      {
        index: 49,
        Date: "2020-02-29T00:00:00.000Z",
        water_usage: 11304461.43,
      },
      {
        index: 50,
        Date: "2020-03-31T00:00:00.000Z",
        water_usage: 16956692.14,
      },
      {
        index: 51,
        Date: "2020-04-30T00:00:00.000Z",
        water_usage: 13188538.33,
      },
      {
        index: 52,
        Date: "2020-05-31T00:00:00.000Z",
        water_usage: 15072615.24,
      },
      {
        index: 53,
        Date: "2020-06-30T00:00:00.000Z",
        water_usage: 9420384.52,
      },
      {
        index: 54,
        Date: "2020-07-31T00:00:00.000Z",
        water_usage: 9420384.52,
      },
      {
        index: 55,
        Date: "2020-08-31T00:00:00.000Z",
        water_usage: 13188538.33,
      },
      {
        index: 56,
        Date: "2020-09-30T00:00:00.000Z",
        water_usage: 45217845.71,
      },
      {
        index: 57,
        Date: "2020-10-31T00:00:00.000Z",
        water_usage: 9420384.52,
      },
      {
        index: 58,
        Date: "2020-11-30T00:00:00.000Z",
        water_usage: 7536307.62,
      },
      {
        index: 59,
        Date: "2020-12-31T00:00:00.000Z",
        water_usage: 28261153.57,
      },
    ],
    pred: [
      {
        Date: "2021-01-01T00:00:00.000Z",
        Prediction: 11340729.4132,
      },
      {
        Date: "2021-02-01T00:00:00.000Z",
        Prediction: 11976299.4965,
      },
      {
        Date: "2021-03-01T00:00:00.000Z",
        Prediction: 17657079.861,
      },
      {
        Date: "2021-04-01T00:00:00.000Z",
        Prediction: 13583983.9288,
      },
      {
        Date: "2021-05-01T00:00:00.000Z",
        Prediction: 15535342.2631,
      },
      {
        Date: "2021-06-01T00:00:00.000Z",
        Prediction: 11138322.7872,
      },
      {
        Date: "2021-07-01T00:00:00.000Z",
        Prediction: 12127375.1283,
      },
      {
        Date: "2021-08-01T00:00:00.000Z",
        Prediction: 10213820.47,
      },
      {
        Date: "2021-09-01T00:00:00.000Z",
        Prediction: 40000934.7484,
      },
      {
        Date: "2021-10-01T00:00:00.000Z",
        Prediction: 12066636.7148,
      },
      {
        Date: "2021-11-01T00:00:00.000Z",
        Prediction: 7718259.4159,
      },
      {
        Date: "2021-12-01T00:00:00.000Z",
        Prediction: 28996052.1447,
      },
    ],
  },
];
